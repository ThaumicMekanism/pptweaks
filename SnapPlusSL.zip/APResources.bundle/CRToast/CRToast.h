//
//  CRToast
//  Copyright (c) 2014-2015 Collin Ruffenach. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CRToast.
FOUNDATION_EXPORT double CRToastVersionNumber;

//! Project version string for CRToast.
FOUNDATION_EXPORT const unsigned char CRToastVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CRToast/PublicHeader.h>

#import <CRToast/CRToastConfig.h>
#import <CRToast/CRToastManager.h>
