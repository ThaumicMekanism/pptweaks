#import "VENTouchLockSplashViewController.h"
#import <BorderButton.h>

@interface SampleLockSplashViewController : VENTouchLockSplashViewController
@property (nonatomic, weak) IBOutlet UIImageView *bgView;
@property (nonatomic, strong) IBOutlet BorderButton *passcodeButton;
@end
