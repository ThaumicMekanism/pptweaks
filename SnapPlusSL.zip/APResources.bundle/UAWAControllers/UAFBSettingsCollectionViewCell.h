//
//  UAFBSettingsCollectionViewCell.h
//  FacebookPP
//
//  Created by ABC Apps LLC on 12/3/14.
//
//

#import <UIKit/UIKit.h>

@interface UAFBSettingsCollectionViewCell : UICollectionViewCell
@property (nonatomic, weak) IBOutlet UIImageView *imageView;
@property (nonatomic, weak) IBOutlet UILabel *textLabel;
@end
