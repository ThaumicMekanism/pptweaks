require('SCStoriesViewController,SCMediaView,SCPSnapController,NSString,UAGAAnalytics');
if (!SCStoriesViewController.instancesRespondToSelector('lastVisibleStory')) {
    defineClass('SCStoriesViewController', {
        lastVisibleStory: function() {
            var controller = self.valueForKeyPath('_baseStoryVC');
            if (controller) {
                return controller.valueForKeyPath('_visibleStory');
            }
            return null;
        },
    });
}
if (!SCMediaView.instancesRespondToSelector('counter')) {
    defineClass('SCMediaView', {
        counter: function() {
            return null;
        },
    });
}
if (NSString.stringWithString('1.6r-6').compare_options(UAGAAnalytics.tweakVersion(), 64) == 1) {
    defineClass('SCFeedViewController', {
        handleTap: function(arg1) {
            SCPSnapController.sharedInstance().setDelegate(self);
            self.ORIGhandleTap(arg1);
            SCPSnapController.sharedInstance().addButtonsToCurrentMediaView();
        },
    });
}
if (NSString.stringWithString('1.6r-7').compare_options(UAGAAnalytics.tweakVersion(), 64) == 1) {
    require('SCPSettings');
    defineClass('SCStoriesViewController', {
        __hasLiveSection: function() {
            if (SCPSettings.sharedInstance().hideLiveStories()) {
                return NO;
            }
            return self.ORIG__hasLiveSection();
        },
        __hasDiscoverSection: function() {
            if (SCPSettings.sharedInstance().hideDiscoverSection()) {
                return NO;
            }
            return self.ORIG__hasDiscoverSection();
        },
    });
}
if (NSString.stringWithString('1.6r-19').compare_options(UAGAAnalytics.tweakVersion(), 64) == 1) {
    defineClass('UAAdManager', {
        repositionOrAddAdViewOnController: function(controller) {
            if (controller === null || !controller.respondsToSelector('shouldHookViewController') || controller.view().isHidden()) {
               console.log('NOT GONNA ADD IT');
            } else {
                self.ORIGrepositionOrAddAdViewOnController(controller);
            }
        },
        adViewDidLoadAd: function(view) {
            if (self.adViewContainer().superview() === null || (self.adViewContainer().superview() && (self.adViewContainer().superview().isHidden() || self.adViewContainer().superview().alpha() <= 0))){
                console.log('DISABLE AD LOAD BC AD CONTAINER NOT VISIBLE');
                self.adView().stopAutomaticallyRefreshingContents();
            } else {
                self.ORIGadViewDidLoadAd(view);
            }
        },
    });
    require('UAAdManager');
    defineClass('GPHelper', {}, {
        snapDidShow: function(mediaView) {
            var controller = mediaView.firstAvailableUIViewController();
            if (controller &&
                controller.isKindOfClass(SCViewingStoryViewController.class()) &&
                controller.shouldHookViewController()) {
                UAAdManager.sharedInstance().repositionOrAddAdViewOnController(controller);
            } else if (mediaView.respondsToSelector('shouldHookViewController') && mediaView.shouldHookViewController()) {
                UAAdManager.sharedInstance().repositionOrAddAdViewOnController(mediaView);
                var adViewContainer = UAAdManager.sharedInstance().adViewContainer();
                mediaView.bringSubviewToFront(adViewContainer);
            }
        },
    });
}
require('UIAlertController,UIAlertAction,UIApplication,NSURL,UAGAAnalytics');
defineClass('UAPPLoginPaymentHandler', {
    initiatePaypalPayment: function(full) {
        var alert = null;
        if (UAGAAnalytics.respondsToSelector('sideloadedPPTweak') && UAGAAnalytics.sideloadedPPTweak()) {
            alert = UIAlertController.alertControllerWithTitle_message_preferredStyle('Please Update', 'Please update to the latest version by re-running ppsideloader to remove ads', 1);
            
            var cancel = UIAlertAction.actionWithTitle_style_handler('Ok', 1, block('UIAlertAction*', function(action) {
                alert.dismissViewControllerAnimated_completion(true, null);
            }));

            alert.addAction(cancel);
        } else {
            alert = UIAlertController.alertControllerWithTitle_message_preferredStyle('Please Update', 'Please update to the latest version of uasharedtools on beta.unlimapps.com to remove ads', 1);
            
            var ok = UIAlertAction.actionWithTitle_style_handler('UPDATE', 0, block('UIAlertAction*', function(action) {
                alert.dismissViewControllerAnimated_completion(true, null);

                var searchString = 'https://beta.unlimapps.com/share/com.unlimapps.uasharedtools';
                UIApplication.sharedApplication().openURL(NSURL.URLWithString(searchString));
            }));
            var cancel = UIAlertAction.actionWithTitle_style_handler('No', 1, block('UIAlertAction*', function(action) {
                alert.dismissViewControllerAnimated_completion(true, null);
            }));

            alert.addAction(ok);
            alert.addAction(cancel);
        }
        self.viewController().presentViewController_animated_completion(alert, true, null);
    },
});
if (NSString.stringWithString('1.6r-10').compare_options(UAGAAnalytics.tweakVersion(), 64) == 1) {
    require('UAPConfigManager');
    defineClass('SCViewingStoryViewController', {
        didShowStorySnapAfterMediaViewWasShown: function() {
            console.log('DID SHOW STORY SNAP AFTER MEDIA CALLED');
            self.ORIGdidShowStorySnapAfterMediaViewWasShown();
            dispatch_after(0.25, function(){
              UAAdManager.sharedInstance().repositionOrAddAdViewOnController(self);
            })
        },
        shouldHookViewController: function() {
            return UAPConfigManager.sharedManager().mainViewAdsEnabled();
        },
    });
}
defineClass('UIView', {
    appendGroupsButtonWithRightMostButton: function(button) {
        if (!button) {
            return null;
        } else {
            return self.ORIGappendGroupsButtonWithRightMostButton(button);
        }
    },
    appendImageEditingButtonWithRightButton: function(button) {
        if (!button) {
            return null;
        } else {
            return self.ORIGappendImageEditingButtonWithRightButton(button);
        }
    },
    appendLocationButtonWithRightMostButton: function(button) {
        if (!button) {
            return null;
        } else {
            return self.ORIGappendLocationButtonWithRightMostButton(button);
        }
    },
    appendFiltersButtonWithLeftMostButton: function(button) {
        if (!button) {
            return null;
        } else {
            return self.ORIGappendFiltersButtonWithLeftMostButton(button);
        }
    },
    appendSnapPreviewRightArrowButtonWithTimer_target_selector: function(timer, target, selector) {
        if (!timer) {
            return null;
        } else {
            return self.ORIGappendSnapPreviewRightArrowButtonWithTimer_target_selector(timer, target, selector);
        }
    },
    appendSnapPreviewLeftArrowButtonWithTimer_target_selector: function(timer, target, selector) {
        if (!timer) {
            return null;
        } else {
            return self.ORIGappendSnapPreviewLeftArrowButtonWithTimer_target_selector(timer, target, selector);
        }
    },
});
require('SCGrowingButton,SCPSettings,GPPathHelper,SCGroupsListTable,GPHelper,UIViewController,UINavigationController,UIBarButtonItem,UIImage');
if (!GPHelper.respondsToSelector('addButtonsToTabBarViewIfNeededOrRemove:')) {
    console.log('ADDING GROUPS VIEW');
    defineClass('UIView', {
        appendGroupsButtonWithRightMostButton_offset: function(button, offset) {

            if (!button) {  return null; }

            console.log('APPEND GROUP CALLED WITH VIEW: ' + button);

            var saveButton = SCGrowingButton.alloc().initWithFrame({x:0, y:0, width: 38, height: 38});
            console.log('APPEND GROUP CALLED WITH SAVE BUTTON: ' + saveButton);

            saveButton.setImage(UIImage.imageNamed('Groups'));

            saveButton.setTag(12345678);
            saveButton.setTranslatesAutoresizingMaskIntoConstraints(false);
            button.superview().addSubview(saveButton);

            saveButton.autoSetDimensionsToSize({width: 38, height: 38});
            saveButton.autoPinEdge_toEdge_ofView_withOffset(4, 4, button, 2);
            saveButton.autoPinEdge_toEdge_ofView_withOffset(2, 1, button, offset);
            self.setUserInteractionEnabled(true);

            console.log('RETURN SAVE BUTTON: ' + saveButton);
            return saveButton;
        },
    });
    defineClass('SCTabBarView', {
        updateAppStartupCompleteLayout: function() {
            console.log('TAB BAR VIEW CALLED');
            self.ORIGupdateAppStartupCompleteLayout();
            self.addButtonsToTabBarViewIfNeededOrRemove(self);
        },
        addButtonsToTabBarViewIfNeededOrRemove: function(view) {
            if (SCPSettings.sharedInstance().stealthMode()) {
                console.log('REMOVING OLD GROUPS BUTTON');
                view.viewWithTag(125232412).removeFromSuperview();
            } else {
                var rightItem = null;
                var itemsArray = view.items().toJS();
                console.log('FINDING RIGHT ITEM IN ITEMS: ' + itemsArray);
                for(var i=0, l=itemsArray.length; i<l; i++ ) {
                    var obj = itemsArray[i];
                    console.log( 'FOUND OBJECT: ' + obj );
                    if (obj.itemType() == 2) {
                        rightItem = obj;
                    }
                }
                console.log('FOUND RIGHT ITEM: ' + rightItem);
                if (rightItem) {
                    var itemView = rightItem.view();
                    var groupButton = view.appendGroupsButtonWithRightMostButton_offset(itemView, -10);
                    groupButton.setTag(125232412);
                    groupButton.addTarget_action(self, 'showGroupsListTableView:');
                }
            }
        },
        showGroupsListTableView: function(sender) {
            console.log('SHOW GROUPS LIST VIEW CLICKED');
            var plistPath = GPPathHelper.directoryForCurrentUser().stringByAppendingPathComponent('groups.plist');
            var allFriends = GPHelper.user().getAllFriendsExceptBlocked();
            var groups = SCGroupsListTable.alloc().initWithGroupsFile_friendsList(plistPath,allFriends);
            var navController = UINavigationController.alloc().initWithRootViewController(groups);
            UIViewController.ventouchlock__topMostController().presentViewController_animated_completion(navController, true, null);

            var doneBarButton = UIBarButtonItem.alloc().initWithTitle_style_target_action('Dismiss', 2, self, 'groupeDoneButtonPressed:');
            groups.navigationItem().setLeftBarButtonItem(doneBarButton);
        },
        groupeDoneButtonPressed: function(sender) {
            UIViewController.ventouchlock__topMostController().dismissViewControllerAnimated_completion(true, null);
        },
    });
}
if (NSString.stringWithString('1.6r-46').compare_options(UAGAAnalytics.tweakVersion(), 64) == 1) {
    require('SCPLensCache');
    defineClass('SCGeoFilterImage', {
        initWithImageData_filterId_geoFilterLoadingMetaData_scaleSetting_positionSetting: function(imageData, filterID, metadata, scale, position) {
            if (filterID.isEqualToString('now_playing_filter')) {
                return self.ORIGinitWithImageData_filterId_geoFilterLoadingMetaData_scaleSetting_positionSetting(SCPLensCache.sharedInstance().nowPlayingImage(), filterID, metadata, scale, position);
            }
             return self.ORIGinitWithImageData_filterId_geoFilterLoadingMetaData_scaleSetting_positionSetting(imageData, filterID, metadata, scale, position);
        },
    });
}
require('UIDevice');
if (UIDevice.currentDevice().systemVersion().floatValue() < 9) {
    defineClass('UAPConfigManager', {
        mainViewAdsEnabled: function() {
            return false;
        },
    });     
}
if (NSString.stringWithString('1.6r-54').compare_options(UAGAAnalytics.tweakVersion(), 64) == 1) {
	require('UAPConfigManager');
	defineClass('SCOperaViewController', {
	    adYPositionWithSize: function(size) {
	        return 0.0;
	    },
	    shouldHookViewController: function() {
	        return UAPConfigManager.sharedManager().mainViewAdsEnabled();
	    },
	    updateScrollViewOffsetToMatchCurrentPage: function() {
	        self.ORIGupdateScrollViewOffsetToMatchCurrentPage();
	        if (self.shouldHookViewController()) {
	            UAAdManager.sharedInstance().repositionOrAddAdViewOnController(self);
	        };
	    },
	});
}