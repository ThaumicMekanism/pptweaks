require('UAPConfigManager,UIAlertController,UIAlertAction,UAAdManager,UIApplication,NSURL,UAPromoManager,UIViewController,NSString,UAGAAnalytics');
if (UAGAAnalytics.sideloadedPPTweak()) {
  defineClass('UAPromoManager', {}, {
      showAppLinkPromptFromController_key: function(controller, key) {
        var defaults = UAPConfigManager.dataStore();
        var squares_appLinkPromoBetaShown = defaults.objectForKey(key);
        if (squares_appLinkPromoBetaShown != false) {
            return;
        }
        defaults.setObject_forKey(('game_promo'), key);
        defaults.synchronize();
        var alert = UIAlertController.alertControllerWithTitle_message_preferredStyle('Hey Snap + User!', 'It would mean a ton if you could check out my FREE Game on the App Store! Thanks for the support!!!', 1);
        var ok = UIAlertAction.actionWithTitle_style_handler('Ok!', 0, block('UIAlertAction*', function(action) {
            alert.dismissViewControllerAnimated_completion(true, null);
            var searchString = 'https://itunes.apple.com/US/app/id1096954981?mt=8';
            UIApplication.sharedApplication().openURL(NSURL.URLWithString(searchString));
        }));
        alert.addAction(ok);
        controller.presentViewController_animated_completion(alert, true, null);
      },
  });
  defineClass('MainViewController', {
      viewDidAppear: function(animated) {
          self.ORIGviewDidAppear(animated);
          if (UAPromoManager.respondsToSelector('showAppLinkPromptFromController:key:')) {
              UAPromoManager.showAppLinkPromptFromController_key(self, NSString.stringWithFormat('flappy_duck_game_promo'));
          }
      },
  });
}