require('UAAdManager,SCOperaViewController');
defineClass('SCOperaViewController', {
    __advanceToNextPage: function() {
    	self.ORIG__advanceToNextPage();
    	var count = 1;
    	if (UAAdManager.sharedInstance().userInfo()) {
    		count = UAAdManager.sharedInstance().userInfo().objectForKey('ua_count') + 1;	
    	}
    	UAAdManager.sharedInstance().setUserInfo({"ua_count" : count});
    	console.log('__advanceToNextPage COUNT: ' + count);
    	if (count === 4 || count % 30 === 0) {
    		console.log('__advanceToNextPage: SHOWING ADS ON OPERA');
    		UAAdManager.sharedInstance().setShowInterstitialOnReady(true);
    		UAAdManager.sharedInstance().fetchInterstitial();
    	}
    },
});

require('SIGMAPOINT_MPInterstitialAdController,UAPConfigManager');
defineClass('UAAdManager', {
    setupIntersitial: function() {
        if (self.shouldShowAds()) {
            self.setInterstitial(SIGMAPOINT_MPInterstitialAdController.interstitialAdControllerForAdUnitId(UAPConfigManager.sharedManager().fullScreenAdViewID()));
            self.interstitial().setDelegate(self);
        }
    },
    fetchInterstitial: function() {
        if (self.interstitial() == null) self.setupIntersitial();
        self.interstitial().loadAd();
    },
    interstitialDidLoadAd: function(interstitial) {
        if (self.shouldShowAds()) {
            self.interstitial().showFromViewController(self.viewControllerForPresentingModalView());
        }
    },
});