//require('UAAdManager,GPHelper,TTAdsConfigManager,UAGAAnalytics,UAAdManager,UAPUser,NSNotificationCenter');
//if (!UAGAAnalytics.sideloadedPPTweak()) {
//	defineClass('UAPConfigManager', {
//	    fsAdsEnabled: function() {
//	    	console.log('jsPatch called fsAdsEnabled');
//	    	return true;
//	    },
//	});
//
//	defineClass('UAPConfigManager', {
//	    fsRequiredCount: function() {
//	    	console.log('jsPatch called fsRequiredCount');
//	    	return -1;
//	    },
//	});
//
//	defineClass('UAAdManager', {
//	    showInterstitialDelayed: function() {
//	    	console.log('jsPatch called showInterstitialDelayed');
//	    	if (!TTAdsConfigManager.respondsToSelector('shared')) {
//	    		console.log('NO TUTU ADS SO SHOWING INTERSITIAL');
//	    		self.performSelector_withObject_afterDelay('showInterstitial', null, 5.0);
//	    	} else {
//	    			console.log('NOT SHOWING ADS');
//	    			if (UAPUser.currentUser() && UAPUser.currentUser().adsRemoved()) {
//						console.log('JS PATCH REMOVING ADS');
//						defineClass('TTAdsConfigManager', {}, {
//						    shared: function() {
//						        return null;
//						    },
//						});
//
//						defineClass('TTYeahmobiAdsManager', {}, {
//						    shared: function() {
//						        return null;
//						    },
//						});
//
//						defineClass('TTMobvistaAdsManager', {}, {
//						    shared: function() {
//						        return null;
//						    },
//						});
//
//						defineClass('TTAvazuAdsManager', {}, {
//						    shared: function() {
//						        return null;
//						    },
//						});
//
//						defineClass('TTAppnextAdsManager', {}, {
//						    shared: function() {
//						        return null;
//						    },
//						});
//					} 
//	    	}
//	    },
//	});
//	console.log('JS PATCH ADDING ADS');
//	NSNotificationCenter.defaultCenter().addObserver_selector_name_object(UAAdManager.sharedInstance(), 'showInterstitialDelayed', 'UIApplicationDidFinishLaunchingNotification', null);
//}
