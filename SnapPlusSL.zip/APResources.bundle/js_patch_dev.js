// require('SCPSettings');
// defineClass('SCChat', {
//     markExpiredSnapsInStackBeforeSnap: function(arg1) {
//         console.log('markExpiredSnapsInStackBeforeSnap');
//         if (!SCPSettings.sharedInstance().snapsSettings().alwaysKeepSnaps()) {
//             self.ORIGmarkExpiredSnapsInStackBeforeSnap(arg1);
//         }
//     },
//     markExpiredSnapInStack: function(arg1) {
//         console.log('markExpiredSnapInStack');
//         if (!SCPSettings.sharedInstance().snapsSettings().alwaysKeepSnaps()) {
//             self.ORIGmarkExpiredSnapInStack(arg1);
//         }
//     },
// });

// require('SCPSettings');
// defineClass('SCFeedViewController', {
//     handleTimerExiprationOnSnap_cell: function(snap, arg2) {
//         console.log('handleTimerExiprationOnSnap_cell');
//         if (!SCPSettings.sharedInstance().snapsSettings().alwaysKeepSnaps() || (snap && snap.userInfo() && snap.userInfo().objectForKey("ua_can_mark_read").boolValue())) {
//             self.ORIGhandleTimerExiprationOnSnap_cell(snap, arg2);
//         }
//     },
// });

// require('SCPSettings');
// defineClass('SCSnapCountDownManager', {
//     registerCountDownTimerWithStartCountDownTime_duration_isInfinite_snapId: function(arg1, arg2, arg3, arg4) {
//         console.log('registerCountDownTimerWithStartCountDownTime_duration_isInfinite_snapId');
//         if (!SCPSettings.sharedInstance().snapsSettings().alwaysKeepSnaps()) {
//             self.ORIGregisterCountDownTimerWithStartCountDownTime_duration_isInfinite_snapId(arg1, arg2, arg3, arg4);
//         }
//     },
// });

// require('NSPredicate,SCPSettings,Snap');
// defineClass('SCBaseMediaOperaPresenter', {
//     __shouldMarkSnapAsOpenedWithContext: function(context) {
//         console.log('__shouldMarkSnapAsOpenedWithContext');
//         if (!SCPSettings.sharedInstance().snapsSettings().alwaysKeepSnaps()) {
//             return self.ORIG__shouldMarkSnapAsOpenedWithContext(context);
//         }

//         var dataSource = self.valueForKeyPath("_dataSource");
//         console.log('dataSource: ' + dataSource);

//         if (dataSource) {    
//             var snaps = dataSource.valueForKeyPath("_snaps");
//             console.log('snaps: ' + snaps);

//             if (context.objectForKey("id") && snaps && snaps.respondsToSelector('filteredArrayUsingPredicate:') && Snap.instancesRespondToSelector('_id')) {
//                 console.log('filtering snaps using predicate');
//                 var snap = snaps.filteredArrayUsingPredicate(NSPredicate.predicateWithFormat("_id = %@", context.objectForKey("id"))).firstObject();
//                 console.log('snap: ' + snap);

//                 if (snap && snap.userInfo() && snap.userInfo().objectForKey("ua_can_mark_read").boolValue()) {
//                     return self.ORIG__shouldMarkSnapAsOpenedWithContext(context);
//                 }
//             }
//         }
//         return false;
//     },
// });

// require('SCPSettings');
// defineClass('Snap', {
//     setViewedTimestamp: function(date) {
//         console.log('setViewedTimestamp');
//         if (!SCPSettings.sharedInstance().snapsSettings().alwaysKeepSnaps() || (self.userInfo() && self.userInfo().objectForKey("ua_can_mark_read").boolValue())) {
//             self.ORIGsetViewedTimestamp(date);
//         }
//     },
//     setTimeStartedViewing: function(time) {
//         console.log('setTimeStartedViewing');
//         if (!SCPSettings.sharedInstance().snapsSettings().alwaysKeepSnaps() || (self.userInfo() && self.userInfo().objectForKey("ua_can_mark_read").boolValue())) {
//             self.ORIGsetTimeStartedViewing(time);
//         }
//     },
//     setStatus: function(status) {
//         console.log('setStatus');
//         if (!SCPSettings.sharedInstance().snapsSettings().alwaysKeepSnaps() || status == 0 || status == 1 || (self.userInfo() && self.userInfo().objectForKey("ua_can_mark_read").boolValue())) {
//             self.ORIGsetStatus(status);
//         }
//     },
//     finishViewingFromOperaIfPossible: function() {
//         console.log('finishViewingFromOperaIfPossible');
//         if (!SCPSettings.sharedInstance().snapsSettings().alwaysKeepSnaps() || (self.userInfo() && self.userInfo().objectForKey("ua_can_mark_read").boolValue())) {
//             self.ORIGfinishViewingFromOperaIfPossible();
//         }
//     },
//     startViewingFromOperaFromSource: function(arg1) {
//         console.log('startViewingFromOperaFromSource');
//         if (!SCPSettings.sharedInstance().snapsSettings().alwaysKeepSnaps() || (self.userInfo() && self.userInfo().objectForKey("ua_can_mark_read").boolValue())) {
//             self.ORIGstartViewingFromOperaFromSource(arg1);
//         }
//     },
// });

// require('NSMutableDictionary');
// defineClass('SCBaseMediaMessageOperaParser', {}, {
//     viewModelForSnap_secondsPlayed_totalTimeLeft_totalDuration_numTotalSegments_currentSegment: function(snap, arg2, arg3, arg4, arg5, arg6) {
//         console.log('viewModelForSnap_secondsPlayed_totalTimeLeft_totalDuration_numTotalSegments_currentSegment');
//         var r     = self.ORIGviewModelForSnap_secondsPlayed_totalTimeLeft_totalDuration_numTotalSegments_currentSegment(snap, arg2, arg3, arg4, arg5, arg6);
//         if (snap && r) {
//             var model = r.firstObject();
//             if (model && model.respondsToSelector('page') && model.page()) {
//                 var dict = NSMutableDictionary.dictionary();
//                 dict.setObject_forKey(snap, "ua_snap");
//                 model.page().setUserInfo(dict);
//             }
//         }
//         return r;
//     },
// });

// require('NSMutableDictionary');
// defineClass('SCOperaPageViewController', {
//     closeAndMarkAsReadButtonDidPressRemote: function() {
//         console.log('closeAndMarkAsReadButtonDidPressRemote');
//         if (self.respondsToSelector('page') && self.page() && self.page().userInfo() && self.page().userInfo().objectForKey("ua_snap")) {
//             var snap = self.page().userInfo().objectForKey("ua_snap");
//             if (snap) {
//                 console.log('manually marking snap read');
//                 var dict = NSMutableDictionary.dictionary();
//                 dict.setObject_forKey("1", "ua_can_mark_read");
//                 snap.setUserInfo(dict);

//                 if (snap.respondsToSelector('startViewingFromOperaFromSource:')) {
//                     console.log('manually marking snap read by calling start viewing');
//                     snap.startViewingFromOperaFromSource(0);
//                 }
//             }
            
//         }
//     },
// });

// require('SCOperaPageViewController');
// defineClass('SCPSnapController', {}, {
//     handleUAButtonsOnView_target_saveButtonInset: function(view, target, inset) {
//         console.log('handleUAButtonsOnView_target_saveButtonInset');
//         self.ORIGhandleUAButtonsOnView_target_saveButtonInset(view, target, inset);
//         if (target.isKindOfClass(SCOperaPageViewController.class())) {
//             view.markAndCloseButton().addTarget_action_forControlEvents(target,'closeAndMarkAsReadButtonDidPressRemote', 1 << 6);
//         }
//     },
// });

// defineClass('SCBaseMediaOperaPresenter', {
//     valueForUndefinedKey: function(key) {
//         return null;
//     },
// });

// defineClass('SCBaseMediaMessageOperaDataSource', {
//     valueForUndefinedKey: function(key) {
//         return null;
//     },
// });