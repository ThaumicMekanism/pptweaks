require('MPGoogleAdMobBannerCustomEvent');
if (!MPGoogleAdMobBannerCustomEvent.respondsToSelector('canRequestAdMobAds')) {
    require('GADRequest');
    defineClass('MPGoogleAdMobBannerCustomEvent', {
        requestAdWithSize_customEventInfo: function(size, info) {
            if (MPGoogleAdMobBannerCustomEvent.canRequestAdMobAds()) {
                self.ORIGrequestAdWithSize_customEventInfo(size,info);
            } else {
                self.delegate().bannerCustomEvent_didFailToLoadAdWithError(self, null);
            }
        },
    }, {
        canRequestAdMobAds: function() {
            return GADRequest.respondsToSelector("sdkVersion") && GADRequest.sdkVersion().isEqualToString("afma-sdk-i-v7.3.1");
        },
    });
}