//
//  SVWebViewControllerActivitySafari.h
//
//  Created by Sam Vermette on 11 Nov, 2013.
//  Copyright 2013 Sam Vermette. All rights reserved.
//
//  https://github.com/samvermette/SVWebViewController

#import "SVWebViewControllerActivity.h"

@interface SVWebViewControllerActivitySafari : SVWebViewControllerActivity

@end
