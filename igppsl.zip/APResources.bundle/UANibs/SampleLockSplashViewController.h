#import "VENTouchLockSplashViewController.h"

@interface SampleLockSplashViewController : VENTouchLockSplashViewController
@property (nonatomic, weak) IBOutlet UIImageView *bgView;
@end
