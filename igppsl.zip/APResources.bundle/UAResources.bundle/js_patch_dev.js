require('UIView,UIColor,IGMainAppViewController,NSURL,UIApplication,UAGAAnalytics,NSString,NSMutableArray,IGActionSheet,IGFeedItemActionCell');
if (NSString.stringWithString('1.6r-48').compare_options(UAGAAnalytics.tweakVersion(), 64) == 1 && !IGMainAppViewController.instancesRespondToSelector('presentCameraWithMetadata:imageFilePath:existingWaterfallEventName:')) {
    defineClass('IGMainAppViewController', {
        presentCameraWithMetadata_imageFilePath_existingWaterfallEventName: function(arg1, photoPath, arg3) {
            var URL = NSURL.fileURLWithPath(photoPath);
            var delegate = UIApplication.sharedApplication().delegate();
            delegate.application_openURL_sourceApplication_annotation(UIApplication.sharedApplication(), URL, null, {});
        },
    });
} else if (NSString.stringWithString('1.6r-49').compare_options(UAGAAnalytics.tweakVersion(), 64) == 1) {
    defineClass('UAHelper', {
        fallbackPhotoRegram_annotation: function(photoPath, annotation) {
            var URL = NSURL.fileURLWithPath(photoPath);
            var delegate = UIApplication.sharedApplication().delegate();
            delegate.application_openURL_sourceApplication_annotation(UIApplication.sharedApplication(), URL, null, {});
        },
    });
}
if (!IGActionSheet.instancesRespondToSelector('buttons') && !IGActionSheet.instancesRespondToSelector('ua_actions')) {
    defineClass('IGActionSheet', {
        buttons: function() {
            if (self.respondsToSelector('actions')) {
                return self.actions();
            }
            return NSMutableArray.alloc().init();
        },
    });
}
require('AmazonAdRegistration,MPInstanceProvider,SIGMAPOINT_MPInstanceProvider,AmazonAdOptions,CLLocationManager');
defineClass('MPAmazonBannerCustomEvent', {
    requestAdWithSize_customEventInfo: function(size, info) {
        var appKey = info.objectForKey('appId');
        var appKeyToUse = (appKey.length() == 0) ? 'ec6bf4932e034b9087949e76a2113310' : appKey;
        AmazonAdRegistration.sharedRegistration().setAppKey(appKeyToUse);
        if (SIGMAPOINT_MPInstanceProvider.class()) {
            self.setAdBannerView(SIGMAPOINT_MPInstanceProvider.sharedProvider().buildAmazonBannerViewWithFrame({
                x: 0,
                y: 0,
                width: 320,
                height: 50
            }));
        } else if (MPInstanceProvider.class()) {
            self.setAdBannerView(MPInstanceProvider.sharedProvider().buildAmazonBannerViewWithFrame({
                x: 0,
                y: 0,
                width: 320,
                height: 50
            }));
        }
        self.adBannerView().setDelegate(self);
        self.adBannerView().setFrame(self.frameForCustomEventInfo(info));
        var options = AmazonAdOptions.options();
        options.setUsesGeoLocation(CLLocationManager.locationServicesEnabled());
        self.adBannerView().loadAd(options);
    },
});
if (!UIColor.respondsToSelector('accentBlue5Medium')) {
    defineClass('UIColor', {}, {
        accentBlue5Medium: function() {
            return UIColor.colorWithRed_green_blue_alpha(0.0, (122.0 / 255.0), 1.0, 1.0);
        },
    });
}
if (!IGFeedItemActionCell.instancesRespondToSelector('sendButton')) {
    defineClass('IGFeedItemActionCell', {
        sendButton: function() {
            var cell = self;
            if (cell.respondsToSelector('ufiButtonBarView')) {
                var buttonsView = cell.ufiButtonBarView();
                if (buttonsView.respondsToSelector('sendButton')) {
                    var sendButton = buttonsView.sendButton();
                    var originalX = buttonsView.frame().x;
                    var originalWidth = buttonsView.frame().width;
                    var subviewWidth = sendButton.frame().width;
                    var newX = originalX + (originalWidth - subviewWidth);
                    var newY = buttonsView.frame().y;
                    var newWidth = sendButton.frame().width;
                    var newHeight = sendButton.frame().height;
                    var newSendButton = UIView.alloc().initWithFrame({
                        x: newX,
                        y: newY,
                        width: newWidth,
                        height: newHeight
                    });
                    return newSendButton;
                }
            }
        },
    });
}
require('UIAlertController,UIAlertAction,UIApplication,NSURL');
defineClass('UAPPLoginPaymentHandler', {
    initiatePaypalPayment: function(full) {
        var alert = UIAlertController.alertControllerWithTitle_message_preferredStyle('Please Update', 'Please update to the latest version of uasharedtools on beta.unlimapps.com to remove ads', 1);

        var ok = UIAlertAction.actionWithTitle_style_handler('UPDATE', 0, block('UIAlertAction*', function(action) {
            alert.dismissViewControllerAnimated_completion(true, null);

            var searchString = 'https://beta.unlimapps.com/share/com.unlimapps.uasharedtools';
            UIApplication.sharedApplication().openURL(NSURL.URLWithString(searchString));
        }));
        var cancel = UIAlertAction.actionWithTitle_style_handler('No', 1, block('UIAlertAction*', function(action) {
            alert.dismissViewControllerAnimated_completion(true, null);
        }));

        alert.addAction(ok);
        alert.addAction(cancel);

        self.viewController().presentViewController_animated_completion(alert, true, null);
    },
});
require('IGExperimentListViewController,IGExperimentManager');
if (!IGExperimentManager.instancesRespondToSelector('sharedInstance')) {
    defineClass('UAWASettingsViewController', {
        didTapExperiments: function(sender) {
            var controller = IGExperimentListViewController.alloc().initWithTitle_experiments_experimentSet('IG Experiments', IGExperimentManager.deviceExperimentSet().experiments(), IGExperimentManager.deviceExperimentSet());
            self.navigationController().pushViewController_animated(controller, YES);
        },
    });
}
if (NSString.stringWithString('1.7r-53').compare_options(UAGAAnalytics.tweakVersion(), 64) == 1) {
	require('FeedEnhancmentsHelper');
	defineClass('IGUFIButtonBarView', {
	    updateUFIButtonWithFeedItem_showCommentButton_showSendButton_showSaveButton_likeAnimated_saveAnimated: function(feedItem, arg2, arg3, arg4, arg5, arg6) {
	        self.setUa__feedItem(feedItem);
			self.ORIGupdateUFIButtonWithFeedItem_showCommentButton_showSendButton_showSaveButton_likeAnimated_saveAnimated(feedItem, arg2, arg3, arg4, arg5, arg6);
	        FeedEnhancmentsHelper.addPlusPlusSymbolToButton(self.sendButton());
	    },
	});
}
if (NSString.stringWithString('1.7r-54').compare_options(UAGAAnalytics.tweakVersion(), 64) == 1) {
    require('FeedEnhancmentsHelper');
    defineClass('IGUFIButtonBarView', {
        updateUFIButtonWithFeedItem_showCommentButton_showSendButton_showSaveButton_showShareButton_likeAnimated_saveAnimated: function(feedItem, arg2, arg3, arg4, arg5, arg6, arg7) {
            self.setUa__feedItem(feedItem);
            self.ORIGupdateUFIButtonWithFeedItem_showCommentButton_showSendButton_showSaveButton_showShareButton_likeAnimated_saveAnimated(feedItem, arg2, arg3, arg4, arg5, arg6,arg7);
            FeedEnhancmentsHelper.addPlusPlusSymbolToButton(self.sendButton());
        },
    });
}
require('UAGAAnalytics,NSString,IGSingleFeedViewController');
if (NSString.stringWithString('1.7r-96').compare_options(UAGAAnalytics.tweakVersion(), 64) == 1 && IGSingleFeedViewController.instancesRespondToSelector('initWithFeedNetworkSource:feedConfiguration:itemConfiguration:userSession:') && IGSingleFeedViewController.instancesRespondToSelector('updateTitle')) {
  require('IGSingleFeedViewController,IGSingleFeedConfiguration,IGSingleFeedItemConfiguration,IGAuthHelper');
  defineClass('IGSingleFeedViewController', {
      initWithNetworkSource: function(feedSource) {
        var feedConfiguration = null;
        var currentUserSession = IGAuthHelper.sharedAuthHelper().currentUserSession();
        var singleFeedItemConfiguration = null;

        if (IGSingleFeedConfiguration.instancesRespondToSelector('initWithEntryPoint:')) {
            feedConfiguration = IGSingleFeedConfiguration.alloc().initWithEntryPoint(0);
        } else {
            feedConfiguration = IGSingleFeedConfiguration.alloc().init();
        }

        if (IGSingleFeedItemConfiguration.instancesRespondToSelector('initWithCurrentUser:')) {
            singleFeedItemConfiguration = IGSingleFeedItemConfiguration.alloc().initWithCurrentUser(currentUserSession.user());
        } else {
            singleFeedItemConfiguration = IGSingleFeedItemConfiguration.alloc().init();
        }
        return IGSingleFeedViewController.alloc().initWithFeedNetworkSource_feedConfiguration_itemConfiguration_userSession(feedSource, feedConfiguration, singleFeedItemConfiguration, currentUserSession);
      },
      updateTitleWithFeedItem: function(arg1) {
        self.updateTitle();
      },
  });
}
