require('UAGAAnalytics,NSString,IGSingleFeedViewController');
if (NSString.stringWithString('1.7r-71').compare_options(UAGAAnalytics.tweakVersion(), 64) == 1 && IGSingleFeedViewController.instancesRespondToSelector('initWithFeedNetworkSource:feedConfiguration:itemConfiguration:userSession:')&& IGSingleFeedViewController.instancesRespondToSelector('updateTitle')) {
  require('IGSingleFeedViewController,IGSingleFeedConfiguration,IGSingleFeedItemConfiguration,IGAuthHelper');
  defineClass('IGSingleFeedViewController', {
      initWithNetworkSource: function(feedSource) {
        var feedConfiguration = IGSingleFeedConfiguration.alloc().init();
        var singleFeedItemConfiguration = IGSingleFeedItemConfiguration.alloc().init();
        var userSession = IGAuthHelper.sharedAuthHelper().currentUserSession();
        return IGSingleFeedViewController.alloc().initWithFeedNetworkSource_feedConfiguration_itemConfiguration_userSession(feedSource, feedConfiguration, singleFeedItemConfiguration, userSession);
      },
      updateTitleWithFeedItem: function(arg1) {
        self.updateTitle();
      },
  });
}
