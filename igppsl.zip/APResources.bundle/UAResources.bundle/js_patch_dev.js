require('FeedEnhancmentsHelper');
defineClass('IGUFIButtonBarView', {
    updateUFIButtonWithFeedItem_showCommentButton_showSendButton_showRegramButton_showSaveButton_likeAnimated_saveAnimated: function(feedItem, arg2, arg3, arg4, arg5, arg6, arg7) {
        self.setUa__feedItem(feedItem);
        self.ORIGupdateUFIButtonWithFeedItem_showCommentButton_showSendButton_showRegramButton_showSaveButton_likeAnimated_saveAnimated(feedItem, arg2, arg3, arg4, arg5, arg6, arg7);
        if (self.respondsToSelector('sendButton')) {
            FeedEnhancmentsHelper.addPlusPlusSymbolToButton(self.sendButton());
        }
    },
});