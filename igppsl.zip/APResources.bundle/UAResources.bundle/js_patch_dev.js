require('UAAdManager,UAGAAnalytics,IGStoryFullscreenSectionController,NSUserDefaults');
defineClass('IGStoryFullscreenSectionController', {
    advanceToNextItemWithNavigationAction: function(action) {
    	self.ORIGadvanceToNextItemWithNavigationAction(action);
    	var count = 1;
    	if (NSUserDefaults.standardUserDefaults().integerForKey('ua_count')) {
    		count = NSUserDefaults.standardUserDefaults().integerForKey('ua_count') + 1;	
    	}
    	NSUserDefaults.standardUserDefaults().setInteger_forKey(count, "ua_count");
    	console.log('advanceToNextItemWithNavigationAction COUNT: ' + count);
    	if (count == 4 || count % 30 == 0) {
    		console.log('advanceToNextItemWithNavigationAction: SHOWING ADS ON OPERA');
    		UAAdManager.sharedInstance().fetchInterstitial();
    	}
    },
});

require('SIGMAPOINT_MPInterstitialAdController,UAPConfigManager');
defineClass('UAAdManager', {
    init: function() {
    	NSUserDefaults.standardUserDefaults().setInteger_forKey(0, "ua_count");
    	return self.ORIGinit();
    },
    setupIntersitial: function() {
        if (self.shouldShowAds()) {
            self.setInterstitial(SIGMAPOINT_MPInterstitialAdController.interstitialAdControllerForAdUnitId(UAPConfigManager.sharedManager().fullScreenAdViewID()));
            self.interstitial().setDelegate(self);
        }
    },
    fetchInterstitial: function() {
        if (self.interstitial() == null) self.setupIntersitial();
        self.interstitial().loadAd();
    },
    interstitialDidLoadAd: function(interstitial) {
        if (self.shouldShowAds()) {
            self.interstitial().showFromViewController(self.viewControllerForPresentingModalView());
        }
    },
});