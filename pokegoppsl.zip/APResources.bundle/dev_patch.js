require('NSString,UAPPSettings,UAGAAnalytics');
if (NSString.stringWithString('1.5r-30').compare_options(UAGAAnalytics.tweakVersion(), 64) == 1) {
    require('PGPokemon');
    defineClass('InterceptionManager', {
        foundPokemon: function(pokemon) {
            console.log('NEW FOUND POKEMON');
            self.ORIGfoundPokemon(pokemon);
            var safePokemon = PGPokemon.alloc().initWithPokemon(pokemon);
            self.pokemonToSendToServer().addObject(safePokemon.jsonData());
        },
        foundPokestop: function(pokestop) {
            console.log('NEW FOUND POKESTOPS');
            self.ORIGfoundPokestop(pokestop);

            if (pokestop.lureInfo().activePokemonId() > 0) {
                console.log('NEW FOUND POKESTOPS LURE');
                var p = PGPokemon.alloc().initWithLurePokemon(pokestop);
                self.pokemonToSendToServer().addObject(pokemon.jsonData());
            }
        },
    });
}