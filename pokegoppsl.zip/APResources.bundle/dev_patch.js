require('NSDate');
defineClass('PGPokemon', {
   initWithPokemon: function(pokemon) {
      var r = self.ORIGinitWithPokemon(pokemon);
       if (r.disappearTime() < 0) {
       		var new_time = Date.now() + (5 * 60 * 1000);
       		console.log('NEW DISSAPEAR TIME: ' + new_time);
            r.setDisappearTime(new_time);
       }
       return r;
   },
});