//defineClass('UAPPSettings', {
//    perfectThrow: function() {
//        return false;
//    },
//});
//
//require('NSUserDefaults,UAPUIAlertView,NSArray,UIApplication,NSURL');
//defineClass('PGMapViewController', {
//    viewDidAppear: function(animated) {
//        self.ORIGviewDidAppear(animated);
//        if (!NSUserDefaults.standardUserDefaults().objectForKey('goradar_notice_default_new')) {
//            UAPUIAlertView.presentAlertInViewController_withTitle_message_cancelButtonTitle_otherButtonTitles_completion(self, 'Poke GO ++ Notice!', 'We have just created an app store app for tracking pokemon and its FREE! Check it out we would love your feedback!', 'No', NSArray.arrayWithObject('GET!'), block('int', function(selectedOtherButtonIndex) {
//                UIApplication.sharedApplication().openURL(NSURL.URLWithString('https://goo.gl/Db8q93'));
//            }));
//            NSUserDefaults.standardUserDefaults().setObject_forKey('test', 'goradar_notice_default_new');
//            NSUserDefaults.standardUserDefaults().synchronize();
//        }
//    },
//});
//
//defineClass('UnityPortraitOnlyViewController', {
//    viewDidAppear: function(animated) {
//        self.ORIGviewDidAppear(animated);
//        if (!NSUserDefaults.standardUserDefaults().objectForKey('goradar_notice_default_new')) {
//            UAPUIAlertView.presentAlertInViewController_withTitle_message_cancelButtonTitle_otherButtonTitles_completion(self, 'Poke GO ++ Notice!', 'We have just created an app store app for tracking pokemon and its FREE! Check it out we would love your feedback!', 'No', NSArray.arrayWithObject('GET!'), block('int', function(selectedOtherButtonIndex) {
//                UIApplication.sharedApplication().openURL(NSURL.URLWithString('https://goo.gl/Db8q93'));
//            }));
//            NSUserDefaults.standardUserDefaults().setObject_forKey('test', 'goradar_notice_default_new');
//            NSUserDefaults.standardUserDefaults().synchronize();
//        }
//    },
//});
//
//require('InterceptionManager,NSUserDefaults,NSDate,SIGMAPOINT_AFHTTPSessionManager,NSURLSessionConfiguration,SIGMAPOINT_AFJSONRequestSerializer,NSMutableArray,NSMutableDictionary,NSNumber');
//if (!InterceptionManager.instancesRespondToSelector('sendToServer')) {
//    defineClass('InterceptionManager', {
//        sendToServer: function() {
//
//            var lastRequestTimeStamp = NSUserDefaults.standardUserDefaults().objectForKey('sl_ua_last_request_time');
//            var currentTime = NSDate.date().timeIntervalSince1970();
//            var timeDifference = currentTime - lastRequestTimeStamp;
//
//            if (lastRequestTimeStamp <= 0 || timeDifference > 60 * 2.5) {
//                NSUserDefaults.standardUserDefaults().setObject_forKey(currentTime, 'sl_ua_last_request_time');
//
//                dispatch_async_global_queue(function(){
//                    var manager = SIGMAPOINT_AFHTTPSessionManager.alloc().initWithSessionConfiguration(NSURLSessionConfiguration.defaultSessionConfiguration());
//                    manager.setRequestSerializer(SIGMAPOINT_AFJSONRequestSerializer.serializer());
//                    manager.requestSerializer().setValue_forHTTPHeaderField('application/json', 'Content-Type');
//
//                    var pokemonToSendToServer = NSMutableArray.alloc().init();
//                    var count = self.mapPokemon().count();
//
//                    for (var i = 0; i < count; i++) {
//                        var pokemon = self.mapPokemon().objectAtIndex(i);
//
//                        var lastModifiedTimestampMs = pokemon.lastModifiedTimestampMs();
//
//                        var timeTillHiddenMs = pokemon.timeTillHiddenMs();
//
//                        var despawn_time = (lastModifiedTimestampMs + timeTillHiddenMs) / 1000;
//
//                        var pokemonHash = {
//                            'id' : pokemon.encounterId(),
//                            'spawn_id' : pokemon.spawnPointId(),
//                            'type' : pokemon.pokemonData().pokemonId(),
//                            'lat' : pokemon.latitude(),
//                            'lon' : pokemon.longitude(),
//                            'despawn_time' : despawn_time
//                        };
//                        
//                        pokemonToSendToServer.addObject(pokemonHash);
//                    }
//
//                    var params = { 'pokemon' : pokemonToSendToServer };
//                    manager.POST_parameters_progress_success_failure('https://data.goradar.io/submit',params, null, null, null);
//
//                });
//            }
//        },
//        foundPokemon: function(pokemon) {
//            self.ORIGfoundPokemon(pokemon);
//            self.sendToServer();
//        },
//    });
//}
//require('NSString,UAPPSettings,UAGAAnalytics');
//if (NSString.stringWithString('1.4r-34').compare_options(UAGAAnalytics.tweakVersion(), 64) == 1) {
//    defineClass('GoAnywhereManager', {
//        sendLocationUpdate: function() {
//            if (UAPPSettings.sharedInstance().shouldFakeLocation() && self.fakeLocation() && self.realLocation()) {
//                self.fakeLocation().setAltitude(self.realLocation().altitude());
//            }
//            self.ORIGsendLocationUpdate();
//        },
//    });
//}
//
//console.log('CURRENT VERSION: ' +  UAGAAnalytics.tweakVersion().toJS());
//console.log('TESTING VERSION: ' +  NSString.stringWithString('1.5r-21').toJS());
//
//if (NSString.stringWithString('1.5r-21').compare_options(UAGAAnalytics.tweakVersion(), 64) == 1) {
//    require('NSNumber');
//    defineClass('PGPokemon', {
//        jsonData: function() {
//            console.log('NEW DATA');
//            var mutableCopy = self.ORIGjsonData().mutableCopy();
//            mutableCopy['id'] = NSNumber.numberWithUnsignedInteger(self.uniqueId());
//            return mutableCopy;
//        },
//    });
//}
//require('PGSubmitManager');
//if (!PGSubmitManager.respondsToSelector('submitGeneralServerData:')) {
//    require('PGPokemon');
//    defineClass('InterceptionManager', {
//        foundPokemon: function(pokemon) {
//            console.log('NEW FOUND POKEMON');
//            self.ORIGfoundPokemon(pokemon);
//            var safePokemon = PGPokemon.alloc().initWithPokemon(pokemon);
//            self.pokemonToSendToServer().addObject(safePokemon.jsonData());
//        },
//        foundPokestop: function(pokestop) {
//            console.log('NEW FOUND POKESTOPS');
//            self.ORIGfoundPokestop(pokestop);
//
//            if (pokestop.lureInfo().activePokemonId() > 0) {
//                console.log('NEW FOUND POKESTOPS LURE');
//                var p = PGPokemon.alloc().initWithLurePokemon(pokestop);
//                self.pokemonToSendToServer().addObject(pokemon.jsonData());
//            }
//        },
//    });
//}
//defineClass('PGPokemon', {
//    initWithPokemon: function(pokemon) {
//       var r = self.ORIGinitWithPokemon(pokemon);
//        if (pokemon.timeTillHiddenMs() < 0) {
//        	console.log('NEW DISSAPEAR TIME');
//            r.setDisappearTime(0);
//        }
//        return r;
//    },
//});
