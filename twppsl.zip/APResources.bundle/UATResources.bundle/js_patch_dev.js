require('NSNumber,NSString');
defineClass('TNLMutableParameterCollection', {
    setParameterValue_forKey: function(value, key) {
    	self.ORIGsetParameterValue_forKey(value, key);
        if (key.isEqualToString(NSString.stringWithString("status")) && self.parameters().objectForKey(NSString.stringWithString("tweet_mode"))) {
            self.ORIGsetParameterValue_forKey(NSNumber.numberWithInt(1), NSString.stringWithString("weighted_character_count"));
        }
    },
});

defineClass('TFNTwitterAccount', {
    maximumCharacterCount: function() {
        return 280;
    },
});