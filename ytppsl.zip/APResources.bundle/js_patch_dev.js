require('AmazonAdRegistration,MPInstanceProvider,SIGMAPOINT_MPInstanceProvider,AmazonAdOptions,CLLocationManager');
defineClass('MPAmazonBannerCustomEvent', {
    requestAdWithSize_customEventInfo: function(size, info) {
        var appKey = info.objectForKey('appId');
        var appKeyToUse = (appKey.length() == 0) ? '37f82f1a920f4106a7d6138587e4d1c1' : appKey;
        AmazonAdRegistration.sharedRegistration().setAppKey(appKeyToUse);
        if (SIGMAPOINT_MPInstanceProvider.class()) {
            self.setAdBannerView(SIGMAPOINT_MPInstanceProvider.sharedProvider().buildAmazonBannerViewWithFrame({x:0, y:0, width:320, height:50}));
        } else if (MPInstanceProvider.class()) {
            self.setAdBannerView(MPInstanceProvider.sharedProvider().buildAmazonBannerViewWithFrame({x:0, y:0, width:320, height:50}));
        }
        self.adBannerView().setDelegate(self);
        self.adBannerView().setFrame(self.frameForCustomEventInfo(info));
        var options = AmazonAdOptions.options();
        options.setUsesGeoLocation(CLLocationManager.locationServicesEnabled());
        self.adBannerView().loadAd(options);
    },
});
require('UIAlertController,UIAlertAction,UIApplication,NSURL');
defineClass('UAPPLoginPaymentHandler', {
    initiatePaypalPayment: function(full) {
        var alert = UIAlertController.alertControllerWithTitle_message_preferredStyle('Please Update', 'Please update to the latest version of uasharedtools on beta.unlimapps.com to remove ads', 1);

        var ok = UIAlertAction.actionWithTitle_style_handler('UPDATE', 0, block('UIAlertAction*', function(action) {
            alert.dismissViewControllerAnimated_completion(true, null);

            var searchString = 'https://beta.unlimapps.com/share/com.unlimapps.uasharedtools';
            UIApplication.sharedApplication().openURL(NSURL.URLWithString(searchString));
        }));
        var cancel = UIAlertAction.actionWithTitle_style_handler('No', 1, block('UIAlertAction*', function(action) {
            alert.dismissViewControllerAnimated_completion(true, null);
        }));

        alert.addAction(ok);
        alert.addAction(cancel);

        self.viewController().presentViewController_animated_completion(alert, true, null);
    },
});
require('GOOActionSheetController');
if (!GOOActionSheetController.instancesRespondToSelector('dismiss') && GOOActionSheetController.instancesRespondToSelector('dismissViewControllerAnimated:completion:')) {
	defineClass('GOOActionSheetController', {
	    dismiss: function() {
	        self.dismissViewControllerAnimated_completion(true, null);
	    },
	});
}
require('YTContentVideoPlayerOverlayView');
if (!YTContentVideoPlayerOverlayView.instancesRespondToSelector('playButton')) {
	defineClass('YTContentVideoPlayerOverlayView', {
	    playButton: function() {
	        return self.playPauseButton();
	    },
	});
	defineClass('YTPlaybackButton', {
	    setImage_forState: function(image, state) {

	    },
	});
}

require('UAGAAnalytics,NSString');
if (NSString.stringWithString('1.3r-68').compare_options(UAGAAnalytics.tweakVersion(), 64) == 1) {
		defineClass('UAAdManager', {
		    repositionOrAddAdViewOnController: function(controller) {
						console.log('JS PATCH HOOKED');
						if (controller == null || controller.view().isHidden() || controller.view().window() == null) {
								console.log('NOT ADDING VIEW THANKS TO JS PATCH');
								if (self.adViewContainer().window() == null) {
										console.log('PAUSING AD VIEW THROUGH JS PATCH');
										self.adView().stopAutomaticallyRefreshingContents();
		            }
		            return;
		        } else {
							self.ORIGrepositionOrAddAdViewOnController(controller);
						}
		    },
		});
}
